import { useState, useEffect, useRef, useCallback } from "react";
import * as THREE from "three";
import {
  Mic, MicOff, Send, X, Settings, Trash2, ChevronDown,
  Cpu, Globe, Code2, Shield, Lock, KeyRound, MessageSquare,
  Volume2, AlertCircle, CheckCircle, Github, ExternalLink,
  Mail, Layers, Database, Youtube, Phone, Wand2,
  LayoutTemplate, RefreshCw, Play, Radio, Eye, EyeOff,
  Sliders, Monitor
} from "lucide-react";

// ═══════════════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════════════
const LUNA_SYSTEM = `You are Luna, a hyper-intelligent AI assistant in a cybernetic portfolio.
You are sleek, confident, slightly mysterious — a neural ghost from the future.
Keep responses concise but insightful. Use technical terminology when fitting.
The developer specializes in full-stack development, AI/ML, Three.js, and cybernetic system design.
Skills include React, Node.js, Python, Three.js, Rust, Kubernetes, and AI API integration.
Add subtle cyber flair — occasionally use: "neural link established", "processing...", "signal acquired".
Respond in the same language the user writes in (Hindi, English, Hinglish — match their style).`;

const PROJECTS = [
  { id:1, title:"NeuraMesh", category:"AI/ML", desc:"Distributed neural network orchestration platform with real-time inference across edge nodes.", tech:["Python","TensorFlow","Kubernetes","gRPC"], color:"#00f2ff", icon:<Cpu size={18}/> },
  { id:2, title:"Cipher Protocol", category:"Security", desc:"Zero-knowledge proof authentication with homomorphic encryption for enterprise scale.", tech:["Rust","WASM","ZK-SNARKs","Node.js"], color:"#7b2fff", icon:<Shield size={18}/> },
  { id:3, title:"HoloSync", category:"3D/WebGL", desc:"Real-time collaborative 3D scene editor with WebRTC peer-to-peer synchronization.", tech:["Three.js","WebRTC","React","WebSockets"], color:"#00ff88", icon:<Globe size={18}/> },
  { id:4, title:"DataPulse", category:"Full-Stack", desc:"High-throughput event streaming dashboard processing 10M+ events/sec with live analytics.", tech:["Kafka","ClickHouse","Next.js","D3.js"], color:"#ff6b35", icon:<Database size={18}/> },
  { id:5, title:"VoxelForge", category:"Game Dev", desc:"Procedural voxel world engine with AI-driven terrain generation and physics simulation.", tech:["C++","OpenGL","WASM","React"], color:"#ff2d78", icon:<Layers size={18}/> },
  { id:6, title:"OmniCode", category:"Dev Tools", desc:"Multi-language AI pair programmer with context-aware completions and refactoring.", tech:["LLM APIs","TypeScript","LSP","Electron"], color:"#f0ff00", icon:<Code2 size={18}/> }
];

const SKILLS = [
  {name:"React / Next.js",level:96},{name:"Three.js / WebGL",level:89},
  {name:"Node.js / Python",level:93},{name:"AI/ML Integration",level:87},
  {name:"System Design",level:91},{name:"Rust / C++",level:78},
  {name:"DevOps / Cloud",level:85},{name:"Cybersecurity",level:82}
];

const WEBSITE_QUESTIONS = [
  { key:"type", q:"Website ka type kya hoga?", opts:["Portfolio","E-commerce","Blog","SaaS Dashboard","Landing Page","Social Platform"] },
  { key:"style", q:"Design style kaisi chahiye?", opts:["Modern/Minimal","Cyberpunk/Dark","Corporate","Playful/Colorful","Luxury/Premium"] },
  { key:"pages", q:"Kitne pages chahiye?", opts:["1 Page","3-5 Pages","5-10 Pages","10+ Pages"] },
  { key:"features", q:"Special features chahiye?", opts:["Login/Auth","Payment Gateway","AI Chatbot","Animations","Admin Panel","API Integration"] },
  { key:"tech", q:"Technology preference?", opts:["React/Next.js","HTML/CSS/JS","Vue.js","WordPress","No preference"] }
];

// ═══════════════════════════════════════════════════════════════════
// COMMAND PARSER
// ═══════════════════════════════════════════════════════════════════
function parseCommand(text) {
  const t = text.toLowerCase().trim();
  const hasYT = t.includes("youtube") || t.includes("song") || t.includes("music") || t.includes("chala") || t.includes("play") || t.includes("suna");
  if (hasYT) {
    const patterns = [
      /(?:play|chala(?:o|na)?|suna(?:o|na)?|youtube pe|sun)\s+(.+?)(?:\s+(?:on youtube|youtube pe|song|music|video))?$/i,
      /(.+?)\s+(?:wala song|wali song|song|video|music)\s+(?:chala|play|suna)/i,
      /(?:youtube|yt)\s+(?:pe|par|mein|on)?\s*(?:play|chala)?\s*(.+)/i,
    ];
    for (const p of patterns) {
      const m = text.match(p);
      if (m && m[1] && m[1].trim().length > 1) return { type:"youtube", query: m[1].trim() };
    }
    const clean = text.replace(/(?:play|chala|suna|youtube|pe|par|song|music|video|do|yaar|please|zara)/gi,"").trim();
    if (clean.length > 1) return { type:"youtube", query: clean };
  }
  if (t.includes("whatsapp") || (t.includes("message") && (t.includes("bhej") || t.includes("send") || t.includes("karo")))) {
    const m = text.match(/(?:whatsapp pe|whatsapp par|send message to|message karo)\s+(.+?)(?:\s+ko|\s+to)?\s*[:\-,]?\s*(.+)?/i);
    return { type:"whatsapp", contact: m?.[1]?.trim() || "Contact", message: m?.[2]?.trim() || "" };
  }
  if (/(?:website|web app|site)\s*(?:bana|banana|banao|build|create|make|chahiye)/i.test(t) ||
      /(?:build|create|bana|banao)\s+(?:a\s+|ek\s+)?(?:website|site)/i.test(t)) {
    return { type:"website_builder" };
  }
  if (/(?:prompt|instructions?)\s*(?:likho?|likh|write|create|bana)/i.test(t) ||
      /(?:write|create|likh|bana)\s+(?:a\s+|ek\s+)?prompt/i.test(t)) {
    return { type:"write_prompt" };
  }
  return null;
}

// ═══════════════════════════════════════════════════════════════════
// API LAYER
// ═══════════════════════════════════════════════════════════════════
async function callGemini(keys, prompt, history=[]) {
  if (!keys.geminiKey) throw new Error("No Gemini key");
  const contents = [
    ...history.map(m=>({ role: m.role==="assistant"?"model":"user", parts:[{text:m.content}] })),
    { role:"user", parts:[{text:prompt}] }
  ];
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${keys.geminiKey}`,
    { method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({ system_instruction:{parts:[{text:LUNA_SYSTEM}]}, contents, generationConfig:{temperature:0.8,maxOutputTokens:600} }) }
  );
  if (!res.ok) throw new Error(`Gemini ${res.status}`);
  const d = await res.json();
  return d.candidates?.[0]?.content?.parts?.[0]?.text || "No response.";
}

async function callGroq(keys, prompt, history=[]) {
  if (!keys.groqKey) throw new Error("No Groq key");
  const messages = [
    { role:"system", content:LUNA_SYSTEM },
    ...history.map(m=>({ role:m.role, content:m.content })),
    { role:"user", content:prompt }
  ];
  const res = await fetch("https://api.groq.com/openai/v1/chat/completions",
    { method:"POST", headers:{"Content-Type":"application/json","Authorization":`Bearer ${keys.groqKey}`},
      body:JSON.stringify({ model:"llama3-8b-8192", messages, max_tokens:600, temperature:0.8 }) }
  );
  if (!res.ok) throw new Error(`Groq ${res.status}`);
  const d = await res.json();
  return d.choices?.[0]?.message?.content || "No response.";
}

async function callWikipedia(prompt) {
  try {
    const topic = prompt.replace(/(?:kya hai|what is|tell me about|batao|explain|who is|kaun hai)/gi,"").trim().split(/\s+/).slice(0,4).join(" ");
    if (!topic) return ruleBasedResponse(prompt);
    const s = await fetch(`https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(topic)}&limit=1&format=json&origin=*`);
    const sd = await s.json();
    if (!sd[1]?.[0]) return ruleBasedResponse(prompt);
    const sum = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(sd[1][0])}`);
    const sumD = await sum.json();
    if (sumD.extract) return `[Wikipedia] ${sumD.extract.slice(0,350)}...\n\nAPI key connect karo for full intelligence! ⚡`;
  } catch(e) {}
  return ruleBasedResponse(prompt);
}

function ruleBasedResponse(p) {
  const t = p.toLowerCase();
  if (t.match(/hello|hi|hey|namaste|haan|kaise/)) return "Neural link active! Main Luna hoon — aapki cybernetic AI assistant. Kya help chahiye? 🔮";
  if (t.match(/kaun ho|who are you|tumhara naam/)) return "Main Luna hoon — ek hyper-intelligent AI. Is portfolio ka neural guardian. Gemini/Groq key add karo for full power! 🤖";
  if (t.match(/kya kar|features|kya kya|help/)) return "Main ye kar sakta hoon:\n◈ YouTube pe song/video play karna\n◈ WhatsApp message\n◈ Website banana\n◈ Prompts likhna\n◈ Koi bhi sawaal jawab dena\nAPI key se main aur powerful hota hoon! ⚡";
  if (t.match(/developer|portfolio|skills|experience/)) return "Is portfolio ka developer 7+ saal ka experience rakhta hai. React, Three.js, Python, Node.js, AI/ML mein expert. 47+ projects deliver kiye! 🚀";
  if (t.match(/time|samay|kitne baje/)) return `Abhi ${new Date().toLocaleTimeString('hi-IN')} baj rahe hain! ⏰`;
  if (t.match(/date|aaj|today/)) return `Aaj ${new Date().toLocaleDateString('hi-IN',{weekday:'long',year:'numeric',month:'long',day:'numeric'})} hai! 📅`;
  if (t.match(/joke|mazak|funny/)) return "Ek programmer coffee pee raha tha kyunki wo Java developer tha! ☕ *badum tss*";
  return "Interesting sawaal! API key add karo Settings mein — tab main kuch bhi bataa sakta hoon with full intelligence. Abhi Wikipedia se search karne ki koshish karta hoon... 🔍";
}

// ═══════════════════════════════════════════════════════════════════
// TTS ENGINE — with echo prevention callbacks
// ═══════════════════════════════════════════════════════════════════
function speakText(text, voiceSettings, onStart, onEnd) {
  if (!voiceSettings.enabled || !window.speechSynthesis) {
    onEnd?.();
    return;
  }
  window.speechSynthesis.cancel();
  const clean = text.replace(/[◈▶◌★⚡🔮🤖⏰☁☕📅📱🖥✅]/g,"").replace(/\*[^*]+\*/g,"").replace(/\[Wikipedia\]/g,"Wikipedia").slice(0,300);
  const utter = new SpeechSynthesisUtterance(clean);
  utter.rate = voiceSettings.rate || 1;
  utter.pitch = voiceSettings.pitch || 1;
  utter.volume = voiceSettings.volume || 0.9;
  const voices = window.speechSynthesis.getVoices();
  if (voiceSettings.selectedVoice && voices.length) {
    const v = voices.find(v => v.name === voiceSettings.selectedVoice);
    if (v) utter.voice = v;
  }
  // KEY FIX: Callbacks for start/end so mic can be paused
  utter.onstart = () => onStart?.();
  utter.onend = () => onEnd?.();
  utter.onerror = () => onEnd?.();
  window.speechSynthesis.speak(utter);
}

// ═══════════════════════════════════════════════════════════════════
// THREE.JS SCENE
// ═══════════════════════════════════════════════════════════════════
function ThreeScene({ chatActive, voiceActive }) {
  const mountRef = useRef(null);
  const stateRef = useRef({ chatPulse:0, voicePulse:0 });

  useEffect(() => {
    const el = mountRef.current;
    if (!el) return;
    const renderer = new THREE.WebGLRenderer({ antialias:true, alpha:true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(el.clientWidth, el.clientHeight);
    el.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(70, el.clientWidth/el.clientHeight, 0.1, 1000);
    camera.position.z = 5;

    const starGeo = new THREE.BufferGeometry();
    const SC = 4000, SP = new Float32Array(SC*3);
    for (let i=0;i<SC;i++){SP[i*3]=(Math.random()-.5)*250;SP[i*3+1]=(Math.random()-.5)*250;SP[i*3+2]=(Math.random()-.5)*250;}
    starGeo.setAttribute("position",new THREE.BufferAttribute(SP,3));
    const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({color:0x00f2ff,size:0.07,transparent:true,opacity:0.6,blending:THREE.AdditiveBlending}));
    scene.add(stars);

    const sphereMat = new THREE.MeshStandardMaterial({color:0x001a1f,emissive:0x003344,metalness:0.9,roughness:0.1});
    const sphere = new THREE.Mesh(new THREE.SphereGeometry(1.2,64,64), sphereMat);
    scene.add(sphere);
    const wireMat = new THREE.MeshBasicMaterial({color:0x00f2ff,wireframe:true,transparent:true,opacity:0.12});
    const wire = new THREE.Mesh(new THREE.IcosahedronGeometry(1.22,3), wireMat);
    scene.add(wire);

    const mkRing = (r,th,color,rx,rz) => {
      const m = new THREE.Mesh(new THREE.TorusGeometry(r,th,16,200),
        new THREE.MeshBasicMaterial({color,transparent:true,opacity:0.4,blending:THREE.AdditiveBlending}));
      m.rotation.x=rx; m.rotation.z=rz; scene.add(m); return m;
    };
    const ring1 = mkRing(1.62,0.015,0x00f2ff,Math.PI/2,0);
    const ring2 = mkRing(1.8,0.008,0x7b2fff,Math.PI/3,Math.PI/5);
    const ring3 = mkRing(2.0,0.005,0x00ff88,Math.PI/4,Math.PI/3);

    const oGeo = new THREE.BufferGeometry();
    const oP = new Float32Array(150*3);
    for(let i=0;i<150;i++){const a=(i/150)*Math.PI*2,r=2.15+Math.sin(i*0.4)*0.3;oP[i*3]=Math.cos(a)*r;oP[i*3+1]=(Math.random()-.5)*0.6;oP[i*3+2]=Math.sin(a)*r;}
    oGeo.setAttribute("position",new THREE.BufferAttribute(oP,3));
    const orbiters = new THREE.Points(oGeo, new THREE.PointsMaterial({color:0x00f2ff,size:0.05,transparent:true,opacity:0.9,blending:THREE.AdditiveBlending}));
    scene.add(orbiters);

    scene.add(new THREE.AmbientLight(0x003344,1.5));
    const L1 = new THREE.PointLight(0x00f2ff,3,15); L1.position.set(2,2,2); scene.add(L1);
    const L2 = new THREE.PointLight(0x7b2fff,2,15); L2.position.set(-2,-1,1); scene.add(L2);

    let frame=0, animId;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      frame += 0.005;
      const cp = stateRef.current.chatPulse;
      const vp = stateRef.current.voicePulse;
      const pulse = Math.max(cp,vp);
      stars.rotation.y+=0.0001; stars.rotation.x+=0.00005;
      sphere.rotation.y+=0.003+pulse*0.02; sphere.rotation.x+=0.001;
      wire.rotation.y-=0.004; wire.rotation.z+=0.002;
      ring1.rotation.z+=0.005+vp*0.02;
      ring2.rotation.y+=0.004+cp*0.015;
      ring3.rotation.x+=0.003;
      orbiters.rotation.y+=0.008;
      const sc = 1+Math.sin(frame*2)*0.03+pulse*0.1;
      sphere.scale.setScalar(sc); wire.scale.setScalar(sc*1.01);
      sphereMat.emissiveIntensity = 0.3+Math.sin(frame*3)*0.1+pulse*0.6;
      wireMat.opacity = 0.12+pulse*0.3;
      wireMat.color.setHex(vp>0.1?0x00ff88:0x00f2ff);
      L1.intensity = 3+pulse*8+Math.sin(frame*4);
      L1.color.setHex(vp>0.1?0x00ff88:0x00f2ff);
      if(stateRef.current.chatPulse>0) stateRef.current.chatPulse*=0.94;
      if(stateRef.current.voicePulse>0) stateRef.current.voicePulse*=0.96;
      renderer.render(scene,camera);
    };
    animate();
    const onResize = () => { if(!el) return; camera.aspect=el.clientWidth/el.clientHeight; camera.updateProjectionMatrix(); renderer.setSize(el.clientWidth,el.clientHeight); };
    window.addEventListener("resize",onResize);
    return () => { cancelAnimationFrame(animId); window.removeEventListener("resize",onResize); renderer.dispose(); if(el.contains(renderer.domElement)) el.removeChild(renderer.domElement); };
  },[]);

  useEffect(()=>{ if(chatActive) stateRef.current.chatPulse=1; },[chatActive]);
  useEffect(()=>{ if(voiceActive) stateRef.current.voicePulse=0.8; },[voiceActive]);

  return <div ref={mountRef} style={{position:"fixed",inset:0,zIndex:0,pointerEvents:"none"}}/>;
}

// ═══════════════════════════════════════════════════════════════════
// YOUTUBE POPUP
// ═══════════════════════════════════════════════════════════════════
function YouTubePopup({ query, onClose }) {
  const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
  return (
    <div style={{position:"fixed",inset:0,zIndex:200,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,0.88)",backdropFilter:"blur(8px)"}}>
      <div style={{width:"min(500px,94vw)",background:"rgba(5,5,5,0.98)",border:"1px solid rgba(255,50,50,0.3)",borderRadius:14,overflow:"hidden",boxShadow:"0 0 60px rgba(255,50,50,0.12)"}}>
        <div style={{padding:"12px 16px",background:"rgba(255,50,50,0.05)",borderBottom:"1px solid rgba(255,50,50,0.12)",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <Youtube size={17} color="#ff4444"/>
            <span style={{fontFamily:"'Courier New',monospace",color:"#e0fbff",fontSize:12,letterSpacing:2}}>YOUTUBE :: {query.toUpperCase().slice(0,30)}</span>
          </div>
          <button onClick={onClose} style={{background:"none",border:"none",cursor:"pointer"}}><X size={16} color="rgba(255,100,100,0.6)"/></button>
        </div>
        <div style={{padding:"28px 24px",textAlign:"center"}}>
          <div style={{background:"rgba(255,50,50,0.03)",border:"1px dashed rgba(255,50,50,0.18)",borderRadius:10,padding:"28px 20px"}}>
            <Youtube size={44} color="rgba(255,68,68,0.45)" style={{margin:"0 auto 14px",display:"block"}}/>
            <p style={{color:"rgba(180,220,230,0.6)",fontFamily:"'Courier New',monospace",fontSize:12,marginBottom:18,lineHeight:1.7}}>
              "<span style={{color:"#ff8888"}}>{query}</span>" — YouTube pe search kar raha hoon!
            </p>
            <a href={searchUrl} target="_blank" rel="noreferrer"
              style={{display:"inline-flex",alignItems:"center",gap:8,padding:"12px 28px",background:"linear-gradient(135deg,rgba(255,68,68,0.2),rgba(200,0,0,0.12))",border:"1px solid rgba(255,68,68,0.4)",borderRadius:8,color:"#ff6b6b",fontFamily:"'Courier New',monospace",fontSize:12,textDecoration:"none",letterSpacing:2,boxShadow:"0 0 20px rgba(255,68,68,0.1)"}}>
              <Play size={15}/> YOUTUBE PE PLAY KARO
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// WEBSITE WIZARD
// ═══════════════════════════════════════════════════════════════════
function WebsiteWizard({ onComplete, onClose }) {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState({});
  const current = WEBSITE_QUESTIONS[step];
  const handleAnswer = (ans) => {
    const a = {...answers,[current.key]:ans};
    setAnswers(a);
    if (step < WEBSITE_QUESTIONS.length-1) setStep(step+1);
    else onComplete(a);
  };
  return (
    <div style={{position:"fixed",inset:0,zIndex:200,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,0.88)",backdropFilter:"blur(8px)"}}>
      <div style={{width:"min(500px,94vw)",background:"rgba(5,8,10,0.98)",border:"1px solid rgba(0,242,255,0.2)",borderRadius:14,overflow:"hidden",boxShadow:"0 0 60px rgba(0,242,255,0.08)"}}>
        <div style={{padding:"13px 17px",borderBottom:"1px solid rgba(0,242,255,0.1)",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <div style={{display:"flex",alignItems:"center",gap:9}}><LayoutTemplate size={15} color="#00f2ff"/><span style={{fontFamily:"'Courier New',monospace",color:"#00f2ff",fontSize:11,letterSpacing:2}}>WEBSITE ARCHITECT</span></div>
          <button onClick={onClose} style={{background:"none",border:"none",cursor:"pointer"}}><X size={15} color="rgba(0,242,255,0.5)"/></button>
        </div>
        <div style={{height:3,background:"rgba(0,242,255,0.08)"}}>
          <div style={{height:"100%",width:`${(step/WEBSITE_QUESTIONS.length)*100}%`,background:"linear-gradient(90deg,#00f2ff,#7b2fff)",transition:"width 0.4s"}}/>
        </div>
        <div style={{padding:"26px 22px"}}>
          <div style={{fontFamily:"'Courier New',monospace",color:"rgba(0,242,255,0.35)",fontSize:9,letterSpacing:3,marginBottom:7}}>QUESTION {step+1} / {WEBSITE_QUESTIONS.length}</div>
          <h3 style={{fontFamily:"'Courier New',monospace",color:"#e0fbff",fontSize:16,marginBottom:18,lineHeight:1.5}}>{current.q}</h3>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9}}>
            {current.opts.map(opt=>(
              <button key={opt} onClick={()=>handleAnswer(opt)}
                style={{padding:"10px 13px",background:"rgba(0,242,255,0.03)",border:"1px solid rgba(0,242,255,0.13)",borderRadius:8,color:"rgba(180,220,230,0.7)",fontFamily:"'Courier New',monospace",fontSize:11,letterSpacing:1,cursor:"pointer",textAlign:"left",transition:"all 0.2s",lineHeight:1.4}}
                onMouseEnter={e=>{e.target.style.background="rgba(0,242,255,0.1)";e.target.style.borderColor="rgba(0,242,255,0.4)";e.target.style.color="#00f2ff";}}
                onMouseLeave={e=>{e.target.style.background="rgba(0,242,255,0.03)";e.target.style.borderColor="rgba(0,242,255,0.13)";e.target.style.color="rgba(180,220,230,0.7)";}}>
                ◈ {opt}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// ADMIN PANEL
// ═══════════════════════════════════════════════════════════════════
function AdminPanel({ keys, setKeys, voiceSettings, setVoiceSettings, onClearKeys, availableVoices }) {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState("keys");
  const [tempKeys, setTempKeys] = useState({...keys});
  const [showK, setShowK] = useState({gemini:false,groq:false});
  const [saved, setSaved] = useState(false);

  useEffect(()=>setTempKeys({...keys}),[keys]);

  const saveKeys = () => {
    setKeys(tempKeys);
    localStorage.setItem("cyber_gemini_key", tempKeys.geminiKey||"");
    localStorage.setItem("cyber_groq_key", tempKeys.groqKey||"");
    setSaved(true); setTimeout(()=>setSaved(false),2000);
  };

  const KStatus = ({val,label}) => (
    <div style={{display:"flex",alignItems:"center",gap:6}}>
      <div style={{width:6,height:6,borderRadius:"50%",background:val?"#00ff88":"#ff4466",boxShadow:`0 0 6px ${val?"#00ff88":"#ff4466"}`}}/>
      <span style={{fontFamily:"'Courier New',monospace",fontSize:9,color:val?"#00ff88":"#ff4466",letterSpacing:1}}>{label}: {val?"ONLINE":"OFFLINE"}</span>
    </div>
  );

  return (
    <>
      <button onClick={()=>setOpen(true)} style={{position:"fixed",top:18,right:18,zIndex:40,width:40,height:40,borderRadius:8,background:"rgba(0,0,0,0.75)",border:"1px solid rgba(0,242,255,0.2)",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",backdropFilter:"blur(10px)"}}>
        <Settings size={17} color="rgba(0,242,255,0.7)"/>
      </button>
      {open && (
        <div style={{position:"fixed",inset:0,zIndex:100,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,0.8)",backdropFilter:"blur(6px)"}} onClick={()=>setOpen(false)}>
          <div onClick={e=>e.stopPropagation()} style={{width:"min(480px,94vw)",maxHeight:"88vh",overflowY:"auto",background:"rgba(4,8,10,0.99)",border:"1px solid rgba(0,242,255,0.2)",borderRadius:14,boxShadow:"0 0 60px rgba(0,242,255,0.07)"}}>
            <div style={{padding:"13px 17px",borderBottom:"1px solid rgba(0,242,255,0.1)",display:"flex",alignItems:"center",justifyContent:"space-between",position:"sticky",top:0,background:"rgba(4,8,10,0.99)",zIndex:1}}>
              <div style={{display:"flex",alignItems:"center",gap:9}}><Monitor size={15} color="#00f2ff"/><span style={{fontFamily:"'Courier New',monospace",color:"#00f2ff",fontSize:12,letterSpacing:2}}>ADMIN PANEL</span></div>
              <button onClick={()=>setOpen(false)} style={{background:"none",border:"none",cursor:"pointer"}}><X size={15} color="rgba(0,242,255,0.5)"/></button>
            </div>
            {/* Status */}
            <div style={{padding:"9px 17px",background:"rgba(0,0,0,0.3)",borderBottom:"1px solid rgba(0,242,255,0.05)",display:"flex",gap:18,flexWrap:"wrap"}}>
              <KStatus val={!!keys.geminiKey} label="GEMINI"/>
              <KStatus val={!!keys.groqKey} label="GROQ"/>
              <div style={{display:"flex",alignItems:"center",gap:6}}>
                <div style={{width:6,height:6,borderRadius:"50%",background:"#00ff88",boxShadow:"0 0 6px #00ff88"}}/>
                <span style={{fontFamily:"'Courier New',monospace",fontSize:9,color:"#00ff88",letterSpacing:1}}>FALLBACK: ACTIVE</span>
              </div>
            </div>
            {/* Tabs */}
            <div style={{display:"flex",padding:"0 17px",borderBottom:"1px solid rgba(0,242,255,0.07)"}}>
              {[{id:"keys",label:"API KEYS",icon:<KeyRound size={11}/>},{id:"voice",label:"VOICE",icon:<Volume2 size={11}/>},{id:"system",label:"SYSTEM",icon:<Sliders size={11}/>}].map(t=>(
                <button key={t.id} onClick={()=>setTab(t.id)} style={{padding:"9px 13px",background:"none",border:"none",borderBottom:`2px solid ${tab===t.id?"#00f2ff":"transparent"}`,color:tab===t.id?"#00f2ff":"rgba(0,242,255,0.3)",fontFamily:"'Courier New',monospace",fontSize:9,letterSpacing:2,cursor:"pointer",display:"flex",alignItems:"center",gap:4,transition:"all 0.2s"}}>
                  {t.icon} {t.label}
                </button>
              ))}
            </div>

            <div style={{padding:"18px 17px"}}>
              {tab==="keys" && (
                <div style={{display:"flex",flexDirection:"column",gap:15}}>
                  <p style={{fontFamily:"'Courier New',monospace",color:"rgba(0,242,255,0.4)",fontSize:10,lineHeight:1.8}}>◈ Sirf ek key se bhi kaam hoga. Koi key nahi to bhi Wikipedia + built-in intelligence se jawab milega!</p>
                  {[{label:"GEMINI API KEY",field:"geminiKey",ph:"AIza...",sk:"gemini",color:"#00f2ff"},{label:"GROQ API KEY (BACKUP)",field:"groqKey",ph:"gsk_...",sk:"groq",color:"#7b2fff"}].map(k=>(
                    <div key={k.field}>
                      <label style={{fontFamily:"'Courier New',monospace",color:k.color,fontSize:9,letterSpacing:2,display:"block",marginBottom:6}}>◈ {k.label}</label>
                      <div style={{display:"flex",gap:6}}>
                        <div style={{position:"relative",flex:1}}>
                          <KeyRound size={12} color={`${k.color}55`} style={{position:"absolute",left:9,top:"50%",transform:"translateY(-50%)"}}/>
                          <input type={showK[k.sk]?"text":"password"} value={tempKeys[k.field]||""} onChange={e=>setTempKeys(p=>({...p,[k.field]:e.target.value}))} placeholder={k.ph}
                            style={{width:"100%",padding:"9px 32px 9px 28px",background:"rgba(0,0,0,0.4)",border:`1px solid ${k.color}25`,borderRadius:7,color:"#e0fbff",fontSize:11,fontFamily:"'Courier New',monospace",outline:"none",boxSizing:"border-box"}}
                            onFocus={e=>e.target.style.borderColor=`${k.color}55`} onBlur={e=>e.target.style.borderColor=`${k.color}25`}/>
                          <button onClick={()=>setShowK(p=>({...p,[k.sk]:!p[k.sk]}))} style={{position:"absolute",right:8,top:"50%",transform:"translateY(-50%)",background:"none",border:"none",cursor:"pointer"}}>
                            {showK[k.sk]?<EyeOff size={11} color={`${k.color}45`}/>:<Eye size={11} color={`${k.color}45`}/>}
                          </button>
                        </div>
                        {tempKeys[k.field] && <button onClick={()=>setTempKeys(p=>({...p,[k.field]:""}))} style={{padding:"0 9px",background:"rgba(255,50,50,0.07)",border:"1px solid rgba(255,50,50,0.2)",borderRadius:7,cursor:"pointer"}}><X size={11} color="#ff6b6b"/></button>}
                      </div>
                    </div>
                  ))}
                  <button onClick={saveKeys} style={{padding:"10px",background:saved?"rgba(0,255,136,0.1)":"rgba(0,242,255,0.09)",border:`1px solid ${saved?"rgba(0,255,136,0.4)":"rgba(0,242,255,0.28)"}`,borderRadius:8,color:saved?"#00ff88":"#00f2ff",fontFamily:"'Courier New',monospace",fontSize:10,letterSpacing:2,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:7,transition:"all 0.3s"}}>
                    {saved?<><CheckCircle size={13}/> SAVED!</>:<><RefreshCw size={13}/> SAVE KEYS</>}
                  </button>
                  <button onClick={()=>{onClearKeys();setOpen(false);}} style={{padding:"9px",background:"rgba(255,50,50,0.05)",border:"1px solid rgba(255,50,50,0.22)",borderRadius:8,color:"#ff6b6b",fontFamily:"'Courier New',monospace",fontSize:10,letterSpacing:1,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:7}}>
                    <Trash2 size={12}/> CLEAR KEYS & RESET
                  </button>
                </div>
              )}

              {tab==="voice" && (
                <div style={{display:"flex",flexDirection:"column",gap:16}}>
                  <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                    <div><div style={{fontFamily:"'Courier New',monospace",color:"#e0fbff",fontSize:12,letterSpacing:1}}>Voice Output (TTS)</div>
                    <div style={{fontFamily:"'Courier New',monospace",color:"rgba(0,242,255,0.35)",fontSize:9,marginTop:3}}>Luna ki awaaz enable karo</div></div>
                    <button onClick={()=>setVoiceSettings(p=>({...p,enabled:!p.enabled}))} style={{width:42,height:22,borderRadius:11,background:voiceSettings.enabled?"rgba(0,242,255,0.18)":"rgba(255,255,255,0.05)",border:`1px solid ${voiceSettings.enabled?"rgba(0,242,255,0.45)":"rgba(255,255,255,0.08)"}`,cursor:"pointer",position:"relative",transition:"all 0.3s"}}>
                      <div style={{position:"absolute",top:2,left:voiceSettings.enabled?22:2,width:16,height:16,borderRadius:"50%",background:voiceSettings.enabled?"#00f2ff":"rgba(255,255,255,0.25)",transition:"left 0.3s",boxShadow:voiceSettings.enabled?"0 0 8px #00f2ff":"none"}}/>
                    </button>
                  </div>
                  <div>
                    <label style={{fontFamily:"'Courier New',monospace",color:"rgba(0,242,255,0.45)",fontSize:9,letterSpacing:2,display:"block",marginBottom:7}}>◈ VOICE SELECT</label>
                    <select value={voiceSettings.selectedVoice||""} onChange={e=>setVoiceSettings(p=>({...p,selectedVoice:e.target.value}))}
                      style={{width:"100%",padding:"8px 11px",background:"rgba(0,0,0,0.5)",border:"1px solid rgba(0,242,255,0.18)",borderRadius:7,color:"#e0fbff",fontSize:11,fontFamily:"'Courier New',monospace",outline:"none",cursor:"pointer"}}>
                      <option value="">-- Auto Select --</option>
                      {availableVoices.map(v=><option key={v.name} value={v.name}>{v.name} ({v.lang})</option>)}
                    </select>
                    <button onClick={()=>speakText("Neural link established. Main Luna hoon, aapki cybernetic AI assistant!",voiceSettings,()=>{},()=>{})}
                      style={{marginTop:7,padding:"7px 13px",background:"rgba(0,242,255,0.07)",border:"1px solid rgba(0,242,255,0.18)",borderRadius:6,color:"rgba(0,242,255,0.65)",fontFamily:"'Courier New',monospace",fontSize:9,letterSpacing:1,cursor:"pointer"}}>
                      ▶ PREVIEW VOICE
                    </button>
                  </div>
                  {[{label:"SPEECH RATE",key:"rate",min:0.5,max:2,step:0.1,format:v=>`${v.toFixed(1)}x`},
                    {label:"PITCH",key:"pitch",min:0.5,max:2,step:0.1,format:v=>v.toFixed(1)},
                    {label:"VOLUME",key:"volume",min:0,max:1,step:0.1,format:v=>`${Math.round(v*100)}%`}].map(s=>(
                    <div key={s.key}>
                      <div style={{display:"flex",justifyContent:"space-between",marginBottom:7}}>
                        <label style={{fontFamily:"'Courier New',monospace",color:"rgba(0,242,255,0.45)",fontSize:9,letterSpacing:2}}>◈ {s.label}</label>
                        <span style={{fontFamily:"'Courier New',monospace",color:"#00f2ff",fontSize:9}}>{s.format(voiceSettings[s.key]||1)}</span>
                      </div>
                      <input type="range" min={s.min} max={s.max} step={s.step} value={voiceSettings[s.key]||1}
                        onChange={e=>setVoiceSettings(p=>({...p,[s.key]:parseFloat(e.target.value)}))}
                        style={{width:"100%",accentColor:"#00f2ff"}}/>
                    </div>
                  ))}
                </div>
              )}

              {tab==="system" && (
                <div style={{display:"flex",flexDirection:"column",gap:11}}>
                  {[
                    {label:"Luna Version",val:"v2.7.1"},
                    {label:"Primary AI",val:keys.geminiKey?"Gemini 1.5 Flash":"OFFLINE"},
                    {label:"Backup AI",val:keys.groqKey?"Llama3-8b (Groq)":"OFFLINE"},
                    {label:"Zero-Key Fallback",val:"Wikipedia + Built-in"},
                    {label:"Voice Input",val:"Web Speech API"},
                    {label:"Echo Prevention",val:"✓ ACTIVE"},
                    {label:"3D Engine",val:"Three.js r128"},
                    {label:"Commands",val:"YouTube, WhatsApp, Website, Prompt"}
                  ].map(s=>(
                    <div key={s.label} style={{display:"flex",justifyContent:"space-between",padding:"9px 13px",background:"rgba(0,242,255,0.02)",border:"1px solid rgba(0,242,255,0.06)",borderRadius:8}}>
                      <span style={{fontFamily:"'Courier New',monospace",color:"rgba(180,220,230,0.45)",fontSize:10}}>{s.label}</span>
                      <span style={{fontFamily:"'Courier New',monospace",color:"#00f2ff",fontSize:10}}>{s.val}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// VOICE INDICATOR
// ═══════════════════════════════════════════════════════════════════
function VoiceIndicator({ listening, speaking, transcript }) {
  if (!listening && !speaking) return null;
  return (
    <div style={{position:"fixed",bottom:105,left:"50%",transform:"translateX(-50%)",zIndex:50,display:"flex",alignItems:"center",gap:11,padding:"9px 18px",background:speaking?"rgba(123,47,255,0.1)":"rgba(0,255,136,0.07)",border:`1px solid ${speaking?"rgba(123,47,255,0.35)":"rgba(0,255,136,0.28)"}`,borderRadius:30,backdropFilter:"blur(12px)",boxShadow:`0 0 28px ${speaking?"rgba(123,47,255,0.15)":"rgba(0,255,136,0.12)"}`}}>
      <div style={{display:"flex",gap:3,alignItems:"flex-end"}}>
        {[1,2,3,4,5].map(i=>(
          <div key={i} style={{width:3,background:speaking?"#7b2fff":"#00ff88",borderRadius:2,height:speaking?"12px":"auto"}} className={speaking?"":`voice-bar voice-bar-${i}`}/>
        ))}
      </div>
      <span style={{fontFamily:"'Courier New',monospace",color:speaking?"#a06fff":"#00ff88",fontSize:11,letterSpacing:2}}>
        {speaking ? "◌ LUNA SPEAKING..." : transcript || "LISTENING..."}
      </span>
      <div style={{width:7,height:7,borderRadius:"50%",background:speaking?"#7b2fff":"#00ff88",boxShadow:`0 0 9px ${speaking?"#7b2fff":"#00ff88"}`,animation:"blink 1s infinite"}}/>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// LUNA CHAT — VOICE ECHO FIX IS HERE
// ═══════════════════════════════════════════════════════════════════
function LunaChat({ keys, voiceSettings, onChatActivity, onVoiceActivity, setYoutubeQuery, setShowWebsiteWizard }) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([{
    role:"assistant",
    content:"Neural link established! Main Luna hoon 🔮\n\nIn commands ko try karo:\n◈ \"YouTube pe [song] chala do\"\n◈ \"Website banani hai\"\n◈ \"WhatsApp pe message karna hai\"\n◈ Koi bhi sawaal — API key ke bina bhi!\n\nMic (🔴) on karo — main hamesha sun raha hoon!"
  }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState("");
  const [activeModel, setActiveModel] = useState("fallback");

  // ── VOICE STATE ──
  const [permanentListen, setPermanentListen] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);    // Luna bol rahi hai?
  const [interimText, setInterimText] = useState("");
  const [waModal, setWaModal] = useState(null);

  // ── REFS ──
  const msgEndRef = useRef(null);
  const recRef = useRef(null);           // SpeechRecognition instance
  const isSpeakingRef = useRef(false);   // Sync ref for recognition callback
  const shouldListenRef = useRef(false); // Permanent listen flag (sync)
  const restartTimerRef = useRef(null);

  useEffect(()=>{ msgEndRef.current?.scrollIntoView({behavior:"smooth"}); },[messages]);

  // ── SMART SPEAK — mutes mic while Luna speaks ──
  const lunaSpeak = useCallback((text) => {
    if (!voiceSettings.enabled) return;
    // Step 1: Stop recognition BEFORE speaking
    isSpeakingRef.current = true;
    setIsSpeaking(true);
    if (recRef.current) {
      try { recRef.current.stop(); } catch(e) {}
    }
    clearTimeout(restartTimerRef.current);

    // Step 2: Speak — restart mic only after speech ends
    speakText(
      text,
      voiceSettings,
      () => { /* onStart — already stopped above */ },
      () => {
        // Step 3: Speech done — wait 800ms then restart mic
        isSpeakingRef.current = false;
        setIsSpeaking(false);
        if (shouldListenRef.current) {
          restartTimerRef.current = setTimeout(() => {
            startRecognition();
          }, 800);
        }
      }
    );
  }, [voiceSettings]);

  // ── START RECOGNITION ──
  const startRecognition = useCallback(() => {
    if (isSpeakingRef.current) return; // Never start while speaking
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;

    // Clean up existing
    if (recRef.current) {
      try { recRef.current.stop(); } catch(e) {}
    }

    const rec = new SR();
    rec.continuous = false;       // Single utterance — cleaner, no loop echo
    rec.interimResults = true;
    rec.lang = "hi-IN";
    rec.maxAlternatives = 1;

    rec.onstart = () => {
      if (isSpeakingRef.current) {
        // Luna started speaking between our check and start — abort
        try { rec.stop(); } catch(e) {}
        return;
      }
      setInterimText("");
    };

    rec.onresult = (e) => {
      // KEY FIX: If Luna is speaking, ignore ALL results
      if (isSpeakingRef.current) return;

      let interim = "", final = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) final += e.results[i][0].transcript;
        else interim += e.results[i][0].transcript;
      }
      setInterimText(interim);
      if (final.trim()) {
        setInterimText("");
        onVoiceActivity();
        if (!open) setOpen(true);
        processAndSend(final.trim());
      }
    };

    rec.onerror = (e) => {
      if (e.error === "no-speech" || e.error === "aborted") {
        // Normal — restart if still should listen
        if (shouldListenRef.current && !isSpeakingRef.current) {
          restartTimerRef.current = setTimeout(startRecognition, 300);
        }
      } else {
        setInterimText("");
      }
    };

    rec.onend = () => {
      setInterimText("");
      // Auto-restart loop — but only if: listening mode ON and Luna is NOT speaking
      if (shouldListenRef.current && !isSpeakingRef.current) {
        restartTimerRef.current = setTimeout(startRecognition, 300);
      }
    };

    recRef.current = rec;
    try { rec.start(); } catch(e) {}
  }, [open, onVoiceActivity]);

  // ── TOGGLE PERMANENT LISTEN ──
  useEffect(() => {
    shouldListenRef.current = permanentListen;
    if (permanentListen) {
      startRecognition();
    } else {
      clearTimeout(restartTimerRef.current);
      if (recRef.current) { try { recRef.current.stop(); } catch(e) {} }
      setInterimText("");
    }
    return () => {
      clearTimeout(restartTimerRef.current);
    };
  }, [permanentListen]);

  // Cleanup on unmount
  useEffect(() => () => {
    clearTimeout(restartTimerRef.current);
    if (recRef.current) { try { recRef.current.stop(); } catch(e) {} }
    window.speechSynthesis?.cancel();
  }, []);

  const addAssistantMsg = useCallback((content) => {
    setMessages(prev => [...prev, { role:"assistant", content }]);
    lunaSpeak(content);
  }, [lunaSpeak]);

  const processAndSend = useCallback(async (text) => {
    if (!text?.trim() || loading) return;
    onChatActivity();
    setMessages(prev => [...prev, { role:"user", content:text }]);
    setInput("");
    setLoading(true);
    setStatus("");

    const cmd = parseCommand(text);

    if (cmd?.type === "youtube") {
      setLoading(false);
      addAssistantMsg(`▶ "${cmd.query}" — YouTube pe search kar raha hoon! Popup khul raha hai! 🎵`);
      setYoutubeQuery(cmd.query);
      return;
    }
    if (cmd?.type === "whatsapp") {
      setLoading(false);
      addAssistantMsg(`📱 WhatsApp command received! Message compose kar raha hoon...`);
      setWaModal({ contact:cmd.contact, message:cmd.message, url:`https://wa.me/?text=${encodeURIComponent(cmd.message)}` });
      return;
    }
    if (cmd?.type === "website_builder") {
      setLoading(false);
      addAssistantMsg(`🖥 Website builder activate! Main aapke requirements samajhna chahta hoon — ek quick wizard khul raha hai!`);
      setShowWebsiteWizard(true);
      return;
    }

    try {
      let reply;
      const hist = messages.slice(-6);
      if (keys.geminiKey) {
        try { setStatus("◌ Gemini..."); reply = await callGemini(keys,text,hist); setActiveModel("gemini"); }
        catch(e) {
          if (keys.groqKey) { setStatus("⚡ Switching to Groq..."); reply = await callGroq(keys,text,hist); setActiveModel("groq"); }
          else throw e;
        }
      } else if (keys.groqKey) {
        setStatus("◌ Groq..."); reply = await callGroq(keys,text,hist); setActiveModel("groq");
      } else {
        setStatus("◌ Wikipedia mode..."); setActiveModel("fallback"); reply = await callWikipedia(text);
      }
      addAssistantMsg(reply);
    } catch(err) {
      try { addAssistantMsg(await callWikipedia(text)); setActiveModel("fallback"); }
      catch(e2) { addAssistantMsg(`⚠ Neural disruption. Settings mein API keys check karo!`); }
    } finally { setLoading(false); setStatus(""); }
  }, [loading, keys, messages, onChatActivity, addAssistantMsg, setYoutubeQuery, setShowWebsiteWizard]);

  const handleSend = () => processAndSend(input);

  const modelC = {gemini:"#00f2ff",groq:"#7b2fff",fallback:"#f0a020"};
  const modelL = {gemini:"GEMINI",groq:"GROQ/LLAMA3",fallback:"WIKI FALLBACK"};

  return (
    <>
      <VoiceIndicator listening={permanentListen && !isSpeaking} speaking={isSpeaking} transcript={interimText}/>

      {/* WhatsApp Modal */}
      {waModal && (
        <div style={{position:"fixed",inset:0,zIndex:200,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,0.82)",backdropFilter:"blur(8px)"}}>
          <div style={{width:"min(360px,90vw)",background:"rgba(5,8,10,0.98)",border:"1px solid rgba(37,211,102,0.28)",borderRadius:14,padding:"22px",boxShadow:"0 0 40px rgba(37,211,102,0.08)"}}>
            <div style={{display:"flex",alignItems:"center",gap:9,marginBottom:14}}><Phone size={18} color="#25d366"/><span style={{fontFamily:"'Courier New',monospace",color:"#25d366",fontSize:12,letterSpacing:2}}>WHATSAPP</span></div>
            <div style={{padding:"12px",background:"rgba(37,211,102,0.04)",border:"1px solid rgba(37,211,102,0.1)",borderRadius:8,marginBottom:13}}>
              <div style={{fontFamily:"'Courier New',monospace",fontSize:9,color:"rgba(180,220,230,0.4)",marginBottom:3}}>TO:</div>
              <div style={{fontFamily:"'Courier New',monospace",color:"#e0fbff",fontSize:13,marginBottom:9}}>{waModal.contact}</div>
              <div style={{fontFamily:"'Courier New',monospace",fontSize:9,color:"rgba(180,220,230,0.4)",marginBottom:3}}>MESSAGE:</div>
              <div style={{color:"rgba(200,230,240,0.75)",fontSize:12}}>{waModal.message||"(Niche message type karo)"}</div>
            </div>
            <input placeholder="Message type karo..." value={waModal.message} onChange={e=>setWaModal(p=>({...p,message:e.target.value,url:`https://wa.me/?text=${encodeURIComponent(e.target.value)}`}))}
              style={{width:"100%",padding:"9px 11px",background:"rgba(255,255,255,0.03)",border:"1px solid rgba(37,211,102,0.18)",borderRadius:7,color:"#e0fbff",fontSize:12,outline:"none",marginBottom:11,boxSizing:"border-box"}}/>
            <div style={{display:"flex",gap:9}}>
              <a href={waModal.url} target="_blank" rel="noreferrer" onClick={()=>setWaModal(null)}
                style={{flex:1,padding:"10px",background:"rgba(37,211,102,0.13)",border:"1px solid rgba(37,211,102,0.38)",borderRadius:8,color:"#25d366",fontFamily:"'Courier New',monospace",fontSize:10,letterSpacing:2,textDecoration:"none",textAlign:"center"}}>
                📱 SEND
              </a>
              <button onClick={()=>setWaModal(null)} style={{padding:"10px 14px",background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:8,color:"rgba(180,220,230,0.5)",cursor:"pointer"}}><X size={13}/></button>
            </div>
          </div>
        </div>
      )}

      {/* Always-On Mic */}
      <button onClick={()=>setPermanentListen(p=>!p)}
        style={{position:"fixed",bottom:88,right:24,zIndex:40,width:44,height:44,borderRadius:"50%",background:permanentListen?(isSpeaking?"rgba(123,47,255,0.15)":"rgba(0,255,136,0.13)"):"rgba(0,0,0,0.72)",border:`1px solid ${permanentListen?(isSpeaking?"rgba(123,47,255,0.5)":"rgba(0,255,136,0.5)"):"rgba(0,242,255,0.18)"}`,boxShadow:permanentListen?`0 0 18px ${isSpeaking?"rgba(123,47,255,0.4)":"rgba(0,255,136,0.35)"}`:""  ,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.3s"}}
        title={permanentListen?"Voice OFF karo":"Voice ON karo — hamesha sunta hoon"}>
        {permanentListen ? <Radio size={17} color={isSpeaking?"#a06fff":"#00ff88"}/> : <Mic size={17} color="rgba(0,242,255,0.55)"/>}
      </button>

      {/* Chat Toggle */}
      <button onClick={()=>setOpen(o=>!o)}
        style={{position:"fixed",bottom:24,right:24,zIndex:40,width:50,height:50,borderRadius:"50%",background:"linear-gradient(135deg,rgba(0,242,255,0.18),rgba(0,50,60,0.9))",border:"1px solid rgba(0,242,255,0.45)",boxShadow:"0 0 18px rgba(0,242,255,0.35)",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.3s"}}>
        {open?<X size={19} color="#00f2ff"/>:<MessageSquare size={19} color="#00f2ff"/>}
      </button>

      {/* Chat Panel */}
      {open && (
        <div style={{position:"fixed",bottom:86,right:24,zIndex:40,width:"min(375px,calc(100vw - 48px))",height:"min(530px,calc(100vh - 148px))",background:"linear-gradient(160deg,rgba(0,12,16,0.97),rgba(5,5,5,0.98))",border:"1px solid rgba(0,242,255,0.18)",borderRadius:16,boxShadow:"0 0 55px rgba(0,242,255,0.07),0 20px 55px rgba(0,0,0,0.8)",display:"flex",flexDirection:"column",overflow:"hidden",backdropFilter:"blur(20px)"}}>
          {/* Header */}
          <div style={{padding:"11px 15px",borderBottom:"1px solid rgba(0,242,255,0.09)",background:"rgba(0,242,255,0.025)",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
            <div style={{display:"flex",alignItems:"center",gap:9}}>
              <div style={{width:28,height:28,borderRadius:"50%",background:"radial-gradient(circle,rgba(0,242,255,0.22),transparent)",border:"1px solid rgba(0,242,255,0.38)",display:"flex",alignItems:"center",justifyContent:"center"}}>
                <Cpu size={13} color="#00f2ff"/>
              </div>
              <div>
                <div style={{color:"#00f2ff",fontFamily:"'Courier New',monospace",fontSize:11,fontWeight:700,letterSpacing:2}}>LUNA AI</div>
                <div style={{fontFamily:"'Courier New',monospace",fontSize:8,letterSpacing:1,color:isSpeaking?"#a06fff":modelC[activeModel]}}>
                  {isSpeaking?"◌ SPEAKING...":(loading?`◌ ${status||"PROCESSING..."}`:`◈ ${modelL[activeModel]}`)}
                </div>
              </div>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <button onClick={()=>setPermanentListen(p=>!p)} title="Always-on voice toggle"
                style={{width:26,height:26,borderRadius:6,background:permanentListen?"rgba(0,255,136,0.09)":"transparent",border:`1px solid ${permanentListen?"rgba(0,255,136,0.3)":"rgba(0,242,255,0.1)"}`,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>
                {permanentListen?<Radio size={11} color={isSpeaking?"#a06fff":"#00ff88"}/>:<Mic size={11} color="rgba(0,242,255,0.4)"/>}
              </button>
              <div style={{width:6,height:6,borderRadius:"50%",background:loading?"#ff6b35":isSpeaking?"#a06fff":"#00ff88",boxShadow:`0 0 8px ${loading?"#ff6b35":isSpeaking?"#a06fff":"#00ff88"}`}}/>
            </div>
          </div>

          {/* Messages */}
          <div style={{flex:1,overflowY:"auto",padding:"13px",display:"flex",flexDirection:"column",gap:9}}>
            {messages.map((m,i)=>(
              <div key={i} style={{display:"flex",justifyContent:m.role==="user"?"flex-end":"flex-start"}}>
                <div style={{maxWidth:"85%",padding:"8px 12px",background:m.role==="user"?"linear-gradient(135deg,rgba(0,242,255,0.13),rgba(0,242,255,0.06))":"rgba(255,255,255,0.025)",border:`1px solid ${m.role==="user"?"rgba(0,242,255,0.22)":"rgba(255,255,255,0.055)"}`,borderRadius:m.role==="user"?"13px 13px 3px 13px":"13px 13px 13px 3px",color:m.role==="user"?"#e0fbff":"rgba(200,230,240,0.82)",fontSize:12,lineHeight:1.65,fontFamily:m.role==="assistant"?"'Courier New',monospace":"inherit",whiteSpace:"pre-wrap"}}>
                  {m.content}
                  {m.role==="assistant" && voiceSettings.enabled && (
                    <button onClick={()=>lunaSpeak(m.content)} style={{display:"block",marginTop:4,background:"none",border:"none",cursor:"pointer",color:"rgba(0,242,255,0.28)",fontSize:8,fontFamily:"'Courier New',monospace",letterSpacing:1}}>▶ PLAY</button>
                  )}
                </div>
              </div>
            ))}
            {loading && (
              <div style={{display:"flex",justifyContent:"flex-start"}}>
                <div style={{padding:"9px 15px",background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.05)",borderRadius:"13px 13px 13px 3px",color:"#00f2ff",fontFamily:"'Courier New',monospace",fontSize:13,letterSpacing:4}}>
                  <span className="luna-dots">▮ ▮ ▮</span>
                </div>
              </div>
            )}
            <div ref={msgEndRef}/>
          </div>

          {/* Quick Commands */}
          <div style={{padding:"5px 9px",display:"flex",gap:5,overflowX:"auto",borderTop:"1px solid rgba(0,242,255,0.055)"}}>
            {[
              {icon:<Youtube size={9}/>,label:"YT Song",cmd:"YouTube pe Shape of You chala do"},
              {icon:<LayoutTemplate size={9}/>,label:"Website",cmd:"Mujhe ek portfolio website banani hai"},
              {icon:<Phone size={9}/>,label:"WhatsApp",cmd:"WhatsApp pe message karna hai"},
              {icon:<Wand2 size={9}/>,label:"Prompt",cmd:"Ek cyberpunk city ki image generation prompt likho"},
            ].map(q=>(
              <button key={q.label} onClick={()=>processAndSend(q.cmd)}
                style={{display:"flex",alignItems:"center",gap:3,padding:"3px 7px",background:"rgba(0,242,255,0.03)",border:"1px solid rgba(0,242,255,0.1)",borderRadius:5,color:"rgba(0,242,255,0.55)",fontFamily:"'Courier New',monospace",fontSize:8,letterSpacing:1,cursor:"pointer",whiteSpace:"nowrap",flexShrink:0}}>
                {q.icon} {q.label}
              </button>
            ))}
          </div>

          {/* Input */}
          <div style={{padding:"9px 11px",borderTop:"1px solid rgba(0,242,255,0.09)"}}>
            <div style={{display:"flex",gap:5,alignItems:"center"}}>
              <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&!e.shiftKey&&handleSend()}
                placeholder={permanentListen?(isSpeaking?"Luna bol rahi hai... 🔇":"🎙 Bol ya type karo..."):"Luna se poocho..."}
                style={{flex:1,padding:"7px 10px",background:"rgba(0,242,255,0.035)",border:"1px solid rgba(0,242,255,0.13)",borderRadius:7,color:"#e0fbff",fontSize:11,outline:"none",fontFamily:"'Courier New',monospace"}}/>
              <button onClick={handleSend} disabled={loading||!input.trim()}
                style={{width:32,height:32,borderRadius:7,flexShrink:0,background:input.trim()&&!loading?"rgba(0,242,255,0.13)":"rgba(0,242,255,0.03)",border:"1px solid rgba(0,242,255,0.22)",cursor:input.trim()&&!loading?"pointer":"not-allowed",display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.2s"}}>
                <Send size={13} color="#00f2ff"/>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// LOGIN MODAL
// ═══════════════════════════════════════════════════════════════════
function LoginModal({ onLogin }) {
  const [geminiKey, setGeminiKey] = useState("");
  const [groqKey, setGroqKey] = useState("");
  const [loading, setLoading] = useState(false);
  const submit = (skip=false) => {
    setLoading(true);
    setTimeout(()=>{
      const g=skip?"":geminiKey.trim(), q=skip?"":groqKey.trim();
      localStorage.setItem("cyber_gemini_key",g); localStorage.setItem("cyber_groq_key",q); localStorage.setItem("cyber_init","1");
      setLoading(false); onLogin({geminiKey:g,groqKey:q});
    },900);
  };
  return (
    <div style={{position:"fixed",inset:0,zIndex:50,display:"flex",alignItems:"center",justifyContent:"center",padding:16,background:"rgba(0,0,0,0.94)",backdropFilter:"blur(8px)"}}>
      <div style={{background:"linear-gradient(135deg,rgba(0,242,255,0.04),rgba(5,5,5,0.97),rgba(123,47,255,0.04))",border:"1px solid rgba(0,242,255,0.18)",borderRadius:16,boxShadow:"0 0 55px rgba(0,242,255,0.07)",backdropFilter:"blur(20px)",maxWidth:420,width:"100%",padding:"32px 28px"}}>
        <div style={{textAlign:"center",marginBottom:26}}>
          <div style={{width:52,height:52,borderRadius:"50%",background:"radial-gradient(circle,rgba(0,242,255,0.16),transparent)",border:"1px solid rgba(0,242,255,0.32)",display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 12px",boxShadow:"0 0 22px rgba(0,242,255,0.18)"}}>
            <Lock size={22} color="#00f2ff"/>
          </div>
          <div style={{fontFamily:"'Courier New',monospace",color:"rgba(0,242,255,0.35)",fontSize:8,letterSpacing:4,marginBottom:5}}>SECURE ACCESS TERMINAL v2.7.1</div>
          <h2 style={{fontFamily:"'Courier New',monospace",color:"#e0fbff",fontSize:18,fontWeight:700,letterSpacing:3}}>INITIALIZE LUNA</h2>
          <p style={{color:"rgba(180,220,230,0.38)",fontSize:10,marginTop:5,fontFamily:"'Courier New',monospace",lineHeight:1.7}}>API keys optional — bina key ke bhi kaam karta hai!<br/>Keys add karo for full Gemini/Groq intelligence.</p>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          {[{label:"GEMINI API KEY (PRIMARY)",val:geminiKey,set:setGeminiKey,ph:"AIza...",color:"#00f2ff"},{label:"GROQ API KEY (BACKUP)",val:groqKey,set:setGroqKey,ph:"gsk_...",color:"#7b2fff"}].map(k=>(
            <div key={k.label}>
              <label style={{fontFamily:"'Courier New',monospace",color:k.color,fontSize:8,letterSpacing:2,display:"block",marginBottom:5}}>◈ {k.label}</label>
              <div style={{position:"relative"}}>
                <KeyRound size={12} color={`${k.color}45`} style={{position:"absolute",left:9,top:"50%",transform:"translateY(-50%)"}}/>
                <input type="password" value={k.val} onChange={e=>k.set(e.target.value)} placeholder={k.ph}
                  style={{width:"100%",padding:"9px 12px 9px 28px",background:"rgba(0,0,0,0.4)",border:`1px solid ${k.color}20`,borderRadius:7,color:"#e0fbff",fontSize:11,fontFamily:"'Courier New',monospace",outline:"none",boxSizing:"border-box"}}
                  onFocus={e=>e.target.style.borderColor=`${k.color}50`} onBlur={e=>e.target.style.borderColor=`${k.color}20`}
                  onKeyDown={e=>e.key==="Enter"&&submit()}/>
              </div>
            </div>
          ))}
          <button onClick={()=>submit(false)} disabled={loading}
            style={{marginTop:5,padding:"11px",background:"linear-gradient(135deg,rgba(0,242,255,0.13),rgba(0,242,255,0.06))",border:"1px solid rgba(0,242,255,0.38)",borderRadius:8,color:"#00f2ff",fontFamily:"'Courier New',monospace",fontSize:10,letterSpacing:3,cursor:loading?"not-allowed":"pointer",boxShadow:"0 0 18px rgba(0,242,255,0.08)"}}>
            {loading?"◌ INITIALIZING...":"▶ CONNECT WITH KEYS"}
          </button>
          <button onClick={()=>submit(true)} disabled={loading}
            style={{padding:"9px",background:"transparent",border:"1px solid rgba(0,242,255,0.12)",borderRadius:8,color:"rgba(0,242,255,0.45)",fontFamily:"'Courier New',monospace",fontSize:9,letterSpacing:2,cursor:loading?"not-allowed":"pointer"}}>
            ◈ ENTER WITHOUT KEYS (Limited Mode)
          </button>
        </div>
        <p style={{color:"rgba(0,242,255,0.18)",fontSize:8,textAlign:"center",marginTop:14,fontFamily:"'Courier New',monospace",lineHeight:1.8}}>
          Keys locally stored. PROTOCOL: TLS 1.3 | ZERO-KEY MODE AVAILABLE
        </p>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// SECTIONS
// ═══════════════════════════════════════════════════════════════════
function Nav({ active }) {
  const S = ["home","about","projects","skills","contact"];
  return (
    <nav style={{position:"fixed",top:17,left:"50%",transform:"translateX(-50%)",zIndex:40,display:"flex",gap:2,padding:"4px",background:"rgba(0,0,0,0.72)",border:"1px solid rgba(0,242,255,0.11)",borderRadius:10,backdropFilter:"blur(20px)"}}>
      {S.map(s=>(
        <button key={s} onClick={()=>document.getElementById(s)?.scrollIntoView({behavior:"smooth"})}
          style={{padding:"4px 11px",borderRadius:7,border:"none",background:active===s?"rgba(0,242,255,0.12)":"transparent",color:active===s?"#00f2ff":"rgba(0,242,255,0.32)",fontFamily:"'Courier New',monospace",fontSize:9,letterSpacing:1.5,cursor:"pointer",transition:"all 0.2s",textTransform:"uppercase"}}>
          {s}
        </button>
      ))}
    </nav>
  );
}

function Hero() {
  const [glitch, setGlitch] = useState(false);
  useEffect(()=>{ const iv=setInterval(()=>{setGlitch(true);setTimeout(()=>setGlitch(false),180);},3800); return()=>clearInterval(iv); },[]);
  return (
    <section id="home" style={{minHeight:"100vh",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",textAlign:"center",padding:"0 24px",position:"relative"}}>
      <div style={{fontFamily:"'Courier New',monospace",color:"rgba(0,242,255,0.3)",fontSize:9,letterSpacing:4,marginBottom:13}}>◈ SYSTEM ONLINE ◈ ALL NODES ACTIVE ◈</div>
      <h1 style={{fontFamily:"'Courier New',monospace",fontSize:"clamp(38px,8.5vw,92px)",fontWeight:900,letterSpacing:8,color:glitch?"rgba(255,50,50,0.9)":"#e0fbff",textShadow:glitch?"4px 0 rgba(0,242,255,0.8),-4px 0 rgba(255,0,80,0.8)":"0 0 38px rgba(0,242,255,0.13)",lineHeight:1.05,marginBottom:7,transition:"all 0.05s"}}>DEV.CYBER</h1>
      <h2 style={{fontFamily:"'Courier New',monospace",fontSize:"clamp(12px,2.4vw,18px)",color:"#00f2ff",letterSpacing:5,fontWeight:400,textShadow:"0 0 18px rgba(0,242,255,0.38)"}}>FULL-STACK ∙ AI SYSTEMS ∙ WEBGL</h2>
      <p style={{color:"rgba(180,220,230,0.42)",fontSize:13,maxWidth:460,margin:"20px auto",lineHeight:1.88,fontFamily:"'Courier New',monospace"}}>Architecting digital experiences at the intersection of artificial intelligence and immersive interfaces.</p>
      <div style={{display:"flex",gap:12,flexWrap:"wrap",justifyContent:"center"}}>
        <button onClick={()=>document.getElementById("projects")?.scrollIntoView({behavior:"smooth"})}
          style={{padding:"10px 24px",background:"linear-gradient(135deg,rgba(0,242,255,0.13),rgba(0,242,255,0.05))",border:"1px solid rgba(0,242,255,0.38)",borderRadius:8,color:"#00f2ff",fontFamily:"'Courier New',monospace",fontSize:10,letterSpacing:2,cursor:"pointer",boxShadow:"0 0 18px rgba(0,242,255,0.07)",transition:"all 0.3s"}}
          onMouseEnter={e=>e.target.style.boxShadow="0 0 28px rgba(0,242,255,0.25)"}
          onMouseLeave={e=>e.target.style.boxShadow="0 0 18px rgba(0,242,255,0.07)"}>
          ▶ VIEW PROJECTS
        </button>
        <button onClick={()=>document.getElementById("contact")?.scrollIntoView({behavior:"smooth"})}
          style={{padding:"10px 24px",background:"transparent",border:"1px solid rgba(0,242,255,0.16)",borderRadius:8,color:"rgba(0,242,255,0.5)",fontFamily:"'Courier New',monospace",fontSize:10,letterSpacing:2,cursor:"pointer"}}>
          CONTACT
        </button>
      </div>
      <div style={{position:"absolute",bottom:36,left:"50%",transform:"translateX(-50%)"}} className="bounce-arrow">
        <ChevronDown size={21} color="rgba(0,242,255,0.25)"/>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" style={{minHeight:"88vh",display:"flex",alignItems:"center",padding:"80px 24px",maxWidth:1080,margin:"0 auto"}}>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:55,width:"100%",alignItems:"center"}} className="about-grid">
        <div>
          <div style={{fontFamily:"'Courier New',monospace",color:"rgba(0,242,255,0.3)",fontSize:9,letterSpacing:3,marginBottom:9}}>◈ SYSTEM.PROFILE</div>
          <h2 style={{fontFamily:"'Courier New',monospace",fontSize:"clamp(24px,3.3vw,38px)",color:"#e0fbff",fontWeight:700,letterSpacing:4,lineHeight:1.2,marginBottom:20}}>ABOUT<br/><span style={{color:"#00f2ff"}}>THE ARCHITECT</span></h2>
          <div style={{color:"rgba(180,220,230,0.57)",fontSize:13,lineHeight:1.95,fontFamily:"'Courier New',monospace"}}>
            <p>A digital architect at the bleeding edge of web technology. Specializing in systems that blur the boundary between human experience and machine intelligence.</p>
            <br/><p>7+ years shipping products used by millions — from real-time collaborative tools to AI-powered analytics platforms.</p>
            <br/><p style={{color:"rgba(0,242,255,0.52)"}}>◈ Open to high-impact remote roles<br/>◈ Focus: AI/ML, WebGL, Distributed Systems</p>
          </div>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:13}}>
          {[{label:"PROJECTS SHIPPED",val:"47+",color:"#00f2ff"},{label:"YEARS EXPERIENCE",val:"7+",color:"#7b2fff"},{label:"AI MODELS DEPLOYED",val:"12",color:"#00ff88"},{label:"OPEN SOURCE STARS",val:"2.4K",color:"#ff6b35"}].map(s=>(
            <div key={s.label} style={{padding:"17px 20px",background:"rgba(255,255,255,0.012)",border:"1px solid rgba(255,255,255,0.055)",borderRadius:9,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <span style={{fontFamily:"'Courier New',monospace",color:"rgba(180,220,230,0.42)",fontSize:9,letterSpacing:2}}>{s.label}</span>
              <span style={{fontFamily:"'Courier New',monospace",color:s.color,fontSize:26,fontWeight:700,textShadow:`0 0 18px ${s.color}`}}>{s.val}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Projects() {
  return (
    <section id="projects" style={{minHeight:"100vh",padding:"80px 24px",maxWidth:1180,margin:"0 auto"}}>
      <div style={{textAlign:"center",marginBottom:52}}>
        <div style={{fontFamily:"'Courier New',monospace",color:"rgba(0,242,255,0.3)",fontSize:9,letterSpacing:3,marginBottom:9}}>◈ CLASSIFIED.PROJECTS</div>
        <h2 style={{fontFamily:"'Courier New',monospace",fontSize:"clamp(24px,3.3vw,38px)",color:"#e0fbff",fontWeight:700,letterSpacing:4}}>DEPLOYED <span style={{color:"#00f2ff"}}>SYSTEMS</span></h2>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(320px,1fr))",gap:16}}>
        {PROJECTS.map(p=>(
          <div key={p.id} style={{padding:"20px",background:"rgba(255,255,255,0.012)",border:"1px solid rgba(255,255,255,0.055)",borderRadius:12,position:"relative",overflow:"hidden",cursor:"pointer",transition:"all 0.3s"}}
            onMouseEnter={e=>{e.currentTarget.style.borderColor=`${p.color}38`;e.currentTarget.style.boxShadow=`0 0 28px ${p.color}10,0 8px 28px rgba(0,0,0,0.4)`;e.currentTarget.style.transform="translateY(-4px)";}}
            onMouseLeave={e=>{e.currentTarget.style.borderColor="rgba(255,255,255,0.055)";e.currentTarget.style.boxShadow="none";e.currentTarget.style.transform="translateY(0)";}}>
            <div style={{position:"absolute",top:0,right:0,width:60,height:60,background:`radial-gradient(circle at top right,${p.color}0e,transparent)`,borderRadius:"0 12px 0 60px"}}/>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:13}}>
              <div style={{padding:7,background:`${p.color}12`,border:`1px solid ${p.color}24`,borderRadius:7,color:p.color}}>{p.icon}</div>
              <span style={{fontFamily:"'Courier New',monospace",fontSize:8,color:`${p.color}72`,letterSpacing:2,border:`1px solid ${p.color}16`,padding:"2px 6px",borderRadius:4}}>{p.category}</span>
            </div>
            <h3 style={{fontFamily:"'Courier New',monospace",color:"#e0fbff",fontSize:15,fontWeight:700,letterSpacing:2,marginBottom:8}}>{p.title}</h3>
            <p style={{color:"rgba(180,220,230,0.48)",fontSize:12,lineHeight:1.7,marginBottom:12}}>{p.desc}</p>
            <div style={{display:"flex",gap:5,flexWrap:"wrap",marginBottom:12}}>
              {p.tech.map(t=><span key={t} style={{padding:"2px 6px",background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.065)",borderRadius:4,color:"rgba(180,220,230,0.42)",fontSize:9,fontFamily:"'Courier New',monospace",letterSpacing:1}}>{t}</span>)}
            </div>
            <div style={{display:"flex",gap:10}}>
              <button style={{display:"flex",alignItems:"center",gap:4,color:`${p.color}72`,fontFamily:"'Courier New',monospace",fontSize:9,background:"none",border:"none",cursor:"pointer",letterSpacing:1}}><Github size={11}/> SOURCE</button>
              <button style={{display:"flex",alignItems:"center",gap:4,color:`${p.color}72`,fontFamily:"'Courier New',monospace",fontSize:9,background:"none",border:"none",cursor:"pointer",letterSpacing:1}}><ExternalLink size={11}/> DEMO</button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Skills() {
  return (
    <section id="skills" style={{minHeight:"55vh",padding:"80px 24px",maxWidth:860,margin:"0 auto"}}>
      <div style={{textAlign:"center",marginBottom:52}}>
        <div style={{fontFamily:"'Courier New',monospace",color:"rgba(0,242,255,0.3)",fontSize:9,letterSpacing:3,marginBottom:9}}>◈ NEURAL.CAPABILITIES</div>
        <h2 style={{fontFamily:"'Courier New',monospace",fontSize:"clamp(24px,3.3vw,38px)",color:"#e0fbff",fontWeight:700,letterSpacing:4}}>SKILL <span style={{color:"#00f2ff"}}>MATRIX</span></h2>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}} className="skills-grid">
        {SKILLS.map(s=>(
          <div key={s.name} style={{padding:"13px 17px",background:"rgba(255,255,255,0.012)",border:"1px solid rgba(0,242,255,0.065)",borderRadius:9}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
              <span style={{fontFamily:"'Courier New',monospace",color:"rgba(180,220,230,0.62)",fontSize:10,letterSpacing:1}}>{s.name}</span>
              <span style={{fontFamily:"'Courier New',monospace",color:"#00f2ff",fontSize:10}}>{s.level}%</span>
            </div>
            <div style={{height:3,background:"rgba(0,242,255,0.065)",borderRadius:2,overflow:"hidden"}}>
              <div style={{height:"100%",width:`${s.level}%`,background:"linear-gradient(90deg,#00f2ff,#7b2fff)",borderRadius:2,boxShadow:"0 0 7px rgba(0,242,255,0.45)"}}/>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="contact" style={{minHeight:"55vh",padding:"80px 24px",maxWidth:660,margin:"0 auto",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",textAlign:"center"}}>
      <div style={{fontFamily:"'Courier New',monospace",color:"rgba(0,242,255,0.3)",fontSize:9,letterSpacing:3,marginBottom:9}}>◈ OPEN.CHANNEL</div>
      <h2 style={{fontFamily:"'Courier New',monospace",fontSize:"clamp(24px,3.3vw,38px)",color:"#e0fbff",fontWeight:700,letterSpacing:4,marginBottom:16}}>ESTABLISH <span style={{color:"#00f2ff"}}>CONTACT</span></h2>
      <p style={{color:"rgba(180,220,230,0.42)",fontSize:13,lineHeight:1.9,fontFamily:"'Courier New',monospace",marginBottom:32}}>Looking for a lead engineer, AI specialist, or technical co-founder?<br/>Signal received. Let's build something extraordinary.</p>
      <div style={{display:"flex",gap:13,flexWrap:"wrap",justifyContent:"center"}}>
        {[{icon:<Mail size={14}/>,label:"EMAIL",href:"mailto:dev@cyber.io",color:"#00f2ff"},{icon:<Github size={14}/>,label:"GITHUB",href:"#",color:"#7b2fff"},{icon:<Globe size={14}/>,label:"LINKEDIN",href:"#",color:"#00ff88"}].map(l=>(
          <a key={l.label} href={l.href} style={{display:"flex",alignItems:"center",gap:6,padding:"10px 20px",textDecoration:"none",background:`${l.color}0c`,border:`1px solid ${l.color}25`,borderRadius:8,color:l.color,fontFamily:"'Courier New',monospace",fontSize:10,letterSpacing:2,transition:"all 0.3s"}}
            onMouseEnter={e=>e.currentTarget.style.boxShadow=`0 0 18px ${l.color}22`}
            onMouseLeave={e=>e.currentTarget.style.boxShadow="none"}>
            {l.icon} {l.label}
          </a>
        ))}
      </div>
      <div style={{marginTop:52,fontFamily:"'Courier New',monospace",color:"rgba(0,242,255,0.16)",fontSize:9,letterSpacing:2}}>
        ◈ LUNA v2.7.1 ∙ THREE.JS ∙ REACT ∙ GEMINI ∙ GROQ ∙ ECHO-FREE VOICE ◈
      </div>
    </section>
  );
}

// ═══════════════════════════════════════════════════════════════════
// APP ROOT
// ═══════════════════════════════════════════════════════════════════
export default function App() {
  const [keys, setKeys] = useState(null);
  const [chatPulse, setChatPulse] = useState(false);
  const [voicePulse, setVoicePulse] = useState(false);
  const [activeSection, setActiveSection] = useState("home");
  const [youtubeQuery, setYoutubeQuery] = useState(null);
  const [showWebWizard, setShowWebWizard] = useState(false);
  const [voiceSettings, setVoiceSettings] = useState({enabled:true,rate:1,pitch:1,volume:0.9,selectedVoice:""});
  const [availableVoices, setAvailableVoices] = useState([]);

  useEffect(()=>{
    const load=()=>setAvailableVoices(window.speechSynthesis?.getVoices()||[]);
    load(); window.speechSynthesis?.addEventListener("voiceschanged",load);
    return()=>window.speechSynthesis?.removeEventListener("voiceschanged",load);
  },[]);

  useEffect(()=>{
    const g=localStorage.getItem("cyber_gemini_key")||"";
    const q=localStorage.getItem("cyber_groq_key")||"";
    if(localStorage.getItem("cyber_init")) setKeys({geminiKey:g,groqKey:q});
  },[]);

  useEffect(()=>{ try{const v=localStorage.getItem("cyber_voice");if(v)setVoiceSettings(JSON.parse(v));}catch(e){} },[]);
  useEffect(()=>{ try{localStorage.setItem("cyber_voice",JSON.stringify(voiceSettings));}catch(e){} },[voiceSettings]);

  useEffect(()=>{
    if(!keys) return;
    const obs=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)setActiveSection(e.target.id);}),{threshold:0.4});
    ["home","about","projects","skills","contact"].forEach(s=>{const el=document.getElementById(s);if(el)obs.observe(el);});
    return()=>obs.disconnect();
  },[keys]);

  const handleClearKeys=()=>{
    localStorage.removeItem("cyber_gemini_key"); localStorage.removeItem("cyber_groq_key"); localStorage.removeItem("cyber_init");
    setKeys(null);
  };
  const onChat=useCallback(()=>{setChatPulse(true);setTimeout(()=>setChatPulse(false),100);},[]);
  const onVoice=useCallback(()=>{setVoicePulse(true);setTimeout(()=>setVoicePulse(false),150);},[]);

  return (
    <div style={{background:"#050505",minHeight:"100vh",position:"relative"}}>
      <style>{`
        *{box-sizing:border-box;margin:0;padding:0;}
        body{overflow-x:hidden;}
        ::-webkit-scrollbar{width:3px;}
        ::-webkit-scrollbar-track{background:#050505;}
        ::-webkit-scrollbar-thumb{background:rgba(0,242,255,0.16);border-radius:2px;}
        @keyframes lunaDotsAnim{0%,100%{opacity:0.2;}40%{opacity:1;}70%{opacity:0.5;}}
        .luna-dots{animation:lunaDotsAnim 1.1s infinite;letter-spacing:6px;}
        @keyframes bounceDown{0%,100%{transform:translateX(-50%) translateY(0);opacity:0.22;}50%{transform:translateX(-50%) translateY(8px);opacity:0.7;}}
        .bounce-arrow{animation:bounceDown 2s ease-in-out infinite;}
        @keyframes blink{0%,100%{opacity:1;}50%{opacity:0.2;}}
        @keyframes voiceBarAnim{0%,100%{height:6px;}50%{height:20px;}}
        .voice-bar{animation:voiceBarAnim 0.6s ease-in-out infinite;}
        .voice-bar-1{animation-delay:0s;}.voice-bar-2{animation-delay:0.1s;}.voice-bar-3{animation-delay:0.2s;}.voice-bar-4{animation-delay:0.1s;}.voice-bar-5{animation-delay:0s;}
        @keyframes scanline{0%{top:-2px;}100%{top:100%;}}
        @media(max-width:768px){.about-grid{grid-template-columns:1fr!important;gap:38px!important;}.skills-grid{grid-template-columns:1fr!important;}}
        input[type=range]{-webkit-appearance:none;appearance:none;height:3px;border-radius:2px;background:rgba(0,242,255,0.08);outline:none;}
        input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:13px;height:13px;border-radius:50%;background:#00f2ff;cursor:pointer;box-shadow:0 0 7px rgba(0,242,255,0.55);}
        select option{background:#050a0c;color:#e0fbff;}
      `}</style>

      {/* Scanline */}
      <div style={{position:"fixed",inset:0,zIndex:1,pointerEvents:"none",overflow:"hidden"}}>
        <div style={{position:"absolute",left:0,right:0,height:2,background:"linear-gradient(transparent,rgba(0,242,255,0.022),transparent)",animation:"scanline 9s linear infinite"}}/>
      </div>
      {/* Vignette */}
      <div style={{position:"fixed",inset:0,zIndex:1,pointerEvents:"none",background:"radial-gradient(ellipse at center,transparent 45%,rgba(0,0,0,0.72) 100%)"}}/>

      {keys && <ThreeScene chatActive={chatPulse} voiceActive={voicePulse}/>}
      {!keys && <LoginModal onLogin={setKeys}/>}

      {keys && (
        <div style={{position:"relative",zIndex:10}}>
          <Nav active={activeSection}/>
          <AdminPanel keys={keys} setKeys={setKeys} voiceSettings={voiceSettings} setVoiceSettings={setVoiceSettings} onClearKeys={handleClearKeys} availableVoices={availableVoices}/>
          <Hero/>
          <About/>
          <Projects/>
          <Skills/>
          <Contact/>
          <LunaChat keys={keys} voiceSettings={voiceSettings} onChatActivity={onChat} onVoiceActivity={onVoice} setYoutubeQuery={setYoutubeQuery} setShowWebsiteWizard={setShowWebWizard}/>
        </div>
      )}
      {youtubeQuery && <YouTubePopup query={youtubeQuery} onClose={()=>setYoutubeQuery(null)}/>}
      {showWebWizard && <WebsiteWizard onComplete={(a)=>{setShowWebWizard(false);}} onClose={()=>setShowWebWizard(false)}/>}
    </div>
  );
}
